from aiogram import F, Bot, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import Message, CallbackQuery, FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types.input_file import FSInputFile
from datetime import datetime
import core.database.db as db
import core.keyboards.reply as kb
import logging
import os



# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Set the log level to DEBUG to capture detailed information
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Set the log format
    handlers=[
        logging.FileHandler("bot.log"),  # Log to a file named 'bot.log'
        logging.StreamHandler()  # Also log to the console
    ],
    encoding='utf-8'
)
logger = logging.getLogger(__name__)


SAVE_PATH_FOLDER = 'cv'
client_router = Router()
channel_chat_id = -1002217599643


class cv_up(StatesGroup):
    cv_file = State()



@client_router.message(F.text == 'Показать вакансии 📄')
async def send_titles(message: Message):
    logger.info("User %s requested 'Показать вакансии'", message.from_user.id)
    if await db.name_check(message.from_user.id):
        if not os.path.exists(SAVE_PATH_FOLDER):
            os.mkdir(SAVE_PATH_FOLDER)
        listings = await db.listi()
        if not listings:
            if await db.isitadmin(message.from_user.id):
                await message.answer("В данный момент нет доступных вакансий", reply_markup=kb.admin_panel_addition)
            else:
                await message.answer("В данный момент нет доступных вакансий", reply_markup=kb.main)
        paginated_response = await kb.reports_pagination(listings)
        await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)
    elif await db.name_check(message.from_user.id) == False:
        await message.answer("Вы не зарегистрированы. Введите /start для регистрации.")
        logger.warning("Unregistered user tried to access vacancies") 

@client_router.callback_query(F.data.startswith("next_"))
async def next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@client_router.callback_query(F.data.startswith("prev_"))
async def previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@client_router.callback_query(F.data.startswith("title_"))
async def show_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[1])
    listings = await db.listi()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    description = await db.vacancy_list_description(title)
    back_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Загрузите резюме', callback_data=f"cv_title_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='back')]
    ])
    description_text = description[0] if description else "Описание отсутствует"
    message_text = f"*{title}*\n\n{description_text}"
    

    await callback.message.edit_text(message_text, parse_mode='HTML', reply_markup=back_keyboard)


@client_router.callback_query(F.data == 'back')
async def go_back(callback: CallbackQuery):
    listings = await db.listi()
    paginated_response = await kb.reports_pagination(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@client_router.callback_query(F.data.startswith("cv_title_"))
async def req_cv_title(callback: CallbackQuery, state: FSMContext, bot=Bot):
    number = int(callback.data.split("_")[2])
    listings = await db.listi()
    
    global title_of_chosen_vacancy
    title_of_chosen_vacancy = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    template_path = await db.check_template_existence(title_of_chosen_vacancy)
    try:
        if template_path:
            document = FSInputFile(template_path)
            await bot.send_document(callback.message.chat.id, document)
            await callback.answer("Вы можете использовать этот шаблон для своего резюме")
    except FileNotFoundError:
        await state.clear()
        pass
    await callback.message.edit_text('Отправьте файл')
    await state.set_state(cv_up.cv_file)



@client_router.message(cv_up.cv_file)
async def reg_cv_two(message: Message, state: FSMContext, bot=Bot):
    restricted1, restricted2 = 0, 0
    document = message.document
    file_info = await bot.get_file(document.file_id)
    file_path = file_info.file_path
    
    # Check file extension
    allowed_extensions = ['doc', 'docx', 'rtf', 'pdf', 'odt', 'txt']
    _, extension = os.path.splitext(document.file_name)
    if extension[1:].lower() not in allowed_extensions:
        await message.answer(f"Формат файла не поддерживается. Пожалуйста, отправьте файл в одном из следующих форматов: {', '.join(allowed_extensions)}.\nНажмите /start чтобы попробовать снова")
        logger.warning("User %s uploaded unsupported file format for CV", message.from_user.id)
        await state.clear()
        restricted1 = 1
    
    # Check file size (limit to 10 MB)
    max_file_size = 10 * 1024 * 1024  # 10 MB
    if file_info.file_size > max_file_size:
        await message.answer("Размер файла превышает 10MB. Пожалуйста, отправьте файл меньшего размера.Нажмите /start чтобы попробовать снова")
        logger.warning("User %s uploaded CV file exceeding size limit", message.from_user.id)
        await state.clear()
        restricted2 = 1
    
    if restricted1 == 0 and restricted2 == 0:
        # Сохранение файла в папке 'cv'
        save_path = os.path.join(SAVE_PATH_FOLDER, document.file_name)
        await bot.download_file(file_path, save_path)
        base_name, extension = os.path.splitext(save_path)
        datetimetemp = datetime.today()
        dt_string = str(datetimetemp.strftime("%d_%m_%Y__%H_%M_%S"))
        user_name = await db.file_renaming_name_getting(message.from_user.id)
        new_name = 'Резюме от {name} на должность {vacancy} {date}'.format(name=user_name, vacancy=title_of_chosen_vacancy,date=dt_string)
        new_path = os.path.join(SAVE_PATH_FOLDER, new_name + extension)
        os.rename(save_path, new_path)
        await db.add_cv(message.from_user.id,new_path,title_of_chosen_vacancy)
        if await db.name_check(message.from_user.id): # проверка на наличие имени в бд
            if await db.isitadmin(message.from_user.id):
                await message.answer('Файл загружен', reply_markup=kb.admin_panel_addition)
                logger.info("CV uploaded successfully")   
                
            else:
                await message.answer('Файл загружен', reply_markup=kb.main)
            document = FSInputFile(new_path)
            await bot.send_message(channel_chat_id, f"Получено новое резюме от кандидата: {user_name}\nНа вакансию: {title_of_chosen_vacancy}")
            await bot.send_document(channel_chat_id, document)
            logger.info("CV uploaded in channel")
        else:
            await message.answer("Вы не зарегистрированы. Введите /start для регистрации.")

