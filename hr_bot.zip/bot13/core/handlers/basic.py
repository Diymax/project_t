from aiogram import F, Router, Bot, types
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery
from aiogram.types.input_file import FSInputFile
from core.handlers.client_handler import SAVE_PATH_FOLDER
from datetime import datetime
from main5 import admin_id
from random import randint
import core.database.db as db
import core.keyboards.reply as kb
import logging
import os
import re
import shutil




# SAVE_PATH_FOLDER = 'cv'
SAVE_PATH_FOLDER_TEMPLATES = 'templates'
if not os.path.exists(SAVE_PATH_FOLDER):
    os.mkdir(SAVE_PATH_FOLDER)
if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
    os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)

router = Router()

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Set the log level to DEBUG to capture detailed information
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Set the log format
    handlers=[
        logging.FileHandler("bot.log", 'w',encoding = 'utf-8'),  # Log to a file named 'bot.log'
        logging.StreamHandler()  # Also log to the console
    ]
)

logger = logging.getLogger(__name__)

# Define states
class VacancyForm(StatesGroup):
    vacancy_title = State() # ожидание сообщение с названием вакансии
    vacancy_description = State()

class templateState(StatesGroup):
    template_file = State()
    title = State()

class templateedition(StatesGroup):
    template_file = State()
    

class cv_up(StatesGroup):
    cv_file = State()

class Vacancy_deletion(StatesGroup):
    confirmation = State()

class Template_deletion(StatesGroup):
    confirmation = State()

class name_inserting(StatesGroup):
    name = State()

class cv_removing(StatesGroup):
    confirmation = State()

class edit_title(StatesGroup):
    n_title = State()
    o_title = State()

class edit_description(StatesGroup):
    n_description = State()
    o_description = State()
    # edit_title = State()

class delete_title(StatesGroup):
    delete_title = State()

@router.message(CommandStart())
async def get_start(message: Message, state: FSMContext):
    logger.info("Received /start command from user %s", message.from_user.id)
    await message.answer_sticker('CAACAgIAAxkBAAMpZBAAAfUO9xqQuhom1S8wBMW98ausAAI4CwACTuSZSzKxR9LZT4zQLwQ')
    if await db.name_check(message.from_user.id): # проверка на наличие имени в бд
        logger.info("User %s is registered", message.from_user.id)
        await message.answer('Добро пожаловать!',reply_markup=kb.main)
        if await db.isitadmin(message.from_user.id):
            logger.info("User %s is an admin", message.from_user.id)
            await message.answer(f'Вы авторизовались как администратор!', reply_markup=kb.admin_panel_addition)
    elif await db.name_check(message.from_user.id) == False:
        logger.info("User %s is not registered, prompting for full name", message.from_user.id)
        await message.answer('Введите ФИО')
        await state.set_state(name_inserting.name)
@router.message(name_inserting.name)
async def reg_two(message: Message, state: FSMContext):
    await state.update_data(name = message.text)
    logger.info("Received full name input from user %s: %s", message.from_user.id, message.text)
    data = await state.get_data()
    await db.insert_name(message.from_user.id, data['name'])
    logger.info("User %s successfully registered with name %s", message.from_user.id, message.text)
    await message.answer('Вы успешно зарегистрировались',reply_markup=kb.main)
    if await db.isitadmin(message.from_user.id):
        logger.info("User %s is an admin", message.from_user.id)
        await message.answer(f'Вы авторизовались как администратор!', reply_markup=kb.admin_panel) 
    await state.clear()



@router.message(F.text == 'Панель Администратора 🛠️')
async def admin_enter(message: Message):
    logger.info("User %s requested 'Панель Администратора'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        await message.answer(f'Вы вошли в Панель Администратора 🛠️', reply_markup=kb.admin_panel)
        logger.info("User %s has admin privileges and accessed 'Панель Администратора'", message.from_user.id)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Панель Администратора'", message.from_user.id)

@router.message(F.text == 'Вакансии 💼')
async def admin_enter(message: Message):
    logger.info("User %s requested 'Вакансии'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        await message.answer(f'Вы вошли в панель вакансий', reply_markup=kb.admin_panel_vacancy)
        logger.info("User %s has admin privileges and accessed 'Вакансии'", message.from_user.id)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Вакансии'", message.from_user.id)


@router.message(F.text == 'Шаблоны 📋')
async def admin_enter(message: Message):
    logger.info("User %s requested 'Шаблоны'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        logger.info("User %s has admin privileges and accessed 'Шаблоны'", message.from_user.id)
        if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
            os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)
            logger.debug("Created save path folder for templates at %s", SAVE_PATH_FOLDER_TEMPLATES)
        await message.answer(f'Вы вошли в панель Шаблоны', reply_markup=kb.admin_panel_template)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Шаблоны'", message.from_user.id)


@router.message(F.text == 'Главное меню 🏠')
async def main_menu(message: Message):
    await message.answer('Главное меню 🏠',reply_markup=kb.main)
    logger.info("User %s requested 'Главное меню'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        await message.answer(f'Вы авторизовались как администратор!', reply_markup=kb.admin_panel_addition)
        logger.info("User %s is an admin and accessed 'Главное меню'", message.from_user.id)
@router.message(F.text == '➕ Добавить вакансии 💼')  
async def req_vacancy_title(message: Message, state: FSMContext):
    logger.info("User %s requested to 'Добавить вакансии'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        logger.info("User %s has admin privileges and is adding a vacancy", message.from_user.id)
        await message.answer(f'Напишите название вакансии')
        await state.set_state(VacancyForm.vacancy_title)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to add a vacancy", message.from_user.id)
    

@router.message(VacancyForm.vacancy_title)
async def reg_two(message: Message, state: FSMContext):
    logger.info("Received vacancy title input from user %s: %s", message.from_user.id, message.text)
    await state.update_data(vacancy_titled = message.text)
    data = await state.get_data()
    vacancy_titled = data['vacancy_titled']
    listing = await db.listi_vacancy_unqueity()
    if vacancy_titled not in listing:
        logger.info("Vacancy title '%s' is unique, requesting description", message.text)
        await message.answer(f'Напишите описание вакансии')
        await state.set_state(VacancyForm.vacancy_description)
    else:
        logger.warning("Vacancy title '%s' already exists, prompting user to try again", message.text)
        await message.answer('Вакансия с таким названием уже существует. Попробуйте еще раз. Нажмите кнопку ➕ Добавить вакансии 💼, чтобы добавить вакансию', reply_markup=kb.admin_panel_vacancy)
        await state.clear()

@router.message(VacancyForm.vacancy_description)
async def vacancy_description_adding(message: Message, state: FSMContext):
    await state.update_data(vacancy_description = message.text)
    data = await state.get_data()
    vacancy_title = data['vacancy_titled']
    vacancy_description = data['vacancy_description']
    logger.info("Added vacancy '%s' with description", (await state.get_data())['vacancy_titled'])
    await db.add_vacancy(vacancy_title, vacancy_description)
    await message.answer('Вакансия добавлена', reply_markup=kb.admin_panel_vacancy)
    await state.clear()



@router.message(F.text == 'Дополнительные действия ⚙️')
async def main_menu(message: Message):
    logger.info("User %s requested 'Дополнительные действия'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        logger.info("User %s has admin privileges and accessed 'Дополнительные действия'", message.from_user.id)
        await message.answer(f'Выберите действие', reply_markup=kb.additional_tools)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Дополнительные действия'", message.from_user.id)


@router.message(F.text == '🗑️ Удалить все вакансии 💼')  
async def req_vacancy_title(message: Message, state: FSMContext):
    logger.info("User %s requested 'Удалить все вакансии'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        logger.info("User %s has admin privileges and accessed 'Удалить все вакансии")
        if await db.listi() != []:
            logger.info("Vacancy list is not empty, proceeding with deletion confirmation")
            await message.answer("В данный момент нет доступных вакансий")
            global check_digits
            check_digits = randint(0,9999)
            logger.debug("Generated confirmation code %d for user %s", check_digits, message.from_user.id)
            await message.answer(f'Вы уверены, что хотите удалить все вакансии из базы данных?(Действие затронет и шаблоны)\nЕсли уверены, напишите число: {check_digits}')
            await state.set_state(Vacancy_deletion.confirmation)
        else:
            await message.answer("В данный момент нет доступных вакансий")
            logger.info("No vacancies available for deletion")
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to delete all vacancies", message.from_user.id)
    

@router.message(Vacancy_deletion.confirmation)
async def reg_two(message: Message, state: FSMContext):
    await state.update_data(confirmation = message.text)
    data = await state.get_data()
    if str(data['confirmation']) == str(check_digits):
        await db.delete_vacancy()
        shutil.rmtree(SAVE_PATH_FOLDER_TEMPLATES)
        await message.answer('Все вакансии удалены')
        logger.info("User %s deleted all vacancies", message.from_user.id)
        await state.clear()

    else:
        logger.info("User %s entered incorrect confirmation for vacancy deletion", message.from_user.id)
        await message.answer('Вы ввели число неверно. Отмена операции...',reply_markup=kb.additional_tools )
    await state.clear()

@router.message(F.text == '🗑️ Удалить все шаблоны 📋')  
async def req_template_title(message: Message, state: FSMContext):
    logger.info("User %s requested 'Удалить все шаблоны'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        if not os.path.exists(SAVE_PATH_FOLDER):
            os.mkdir(SAVE_PATH_FOLDER)
        if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
            os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)
        if os.listdir(SAVE_PATH_FOLDER) != []:
            logger.info("Template list is not empty, proceeding with deletion confirmation")
            global check_digits
            check_digits = randint(0,9999)
            logger.debug("Generated confirmation code %d for user %s", check_digits, message.from_user.id)
            await message.answer(f'Вы уверены, что хотите удалить все шаблоны из базы данных и все прикрепленные файлы?\nЕсли уверены, напишите число: {check_digits}')
            await state.set_state(Template_deletion.confirmation)
        else:
            logger.info("No templates available for deletion")
            await message.answer('Нет доступных шаблонов', reply_markup=kb.additional_tools)
            
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to delete all templates", message.from_user.id)

    

@router.message(Template_deletion.confirmation)
async def reg_two(message: Message, state: FSMContext):
    logger.info("Received deletion confirmation input from user %s: %s", message.from_user.id, message.text)
    await state.update_data(confirmation = message.text)
    data = await state.get_data()
    if str(data['confirmation']) == str(check_digits):
        logger.info("User %s provided correct confirmation code, proceeding with template deletion", message.from_user.id)
        await db.delete_all_templates()
        shutil.rmtree(SAVE_PATH_FOLDER_TEMPLATES)
        await message.answer('Все шаблоны удалены')
        logger.info("All templates deleted by user %s", message.from_user.id)
        await state.clear()

    else:
        logger.warning("User %s provided incorrect confirmation code, cancelling template deletion", message.from_user.id)
        await message.answer('Вы ввели число неверно. Отмена операции...',reply_markup=kb.additional_tools )
    await state.clear()

@router.message(F.text == '📥 Скачать все резюме 📝')
async def send_all_files(message: types.Message, bot=Bot):
    logger.info("User %s requested 'Скачать все резюме'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        if os.listdir(SAVE_PATH_FOLDER) != []:
            logger.info("Preparing to send all resume files")
            await message.answer(f'Файлы подготавливаются к скачаиванию', reply_markup=kb.additional_tools)
            files = os.listdir(SAVE_PATH_FOLDER)    
            for file_name in files:
                file_path = os.path.join(SAVE_PATH_FOLDER, file_name)
                if os.path.isfile(file_path):
                    document = FSInputFile(file_path)
                    await bot.send_document(message.chat.id, document)
        else:
            logger.info("No resume files available to send")
            await message.answer('Нет доступных резюме', reply_markup=kb.additional_tools)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to download all resumes", message.from_user.id)

@router.message(F.text == '🗑️Удалить все резюме 📝')  
async def req_vacancy_title(message: Message, state: FSMContext):
    logger.info("User %s requested 'Удалить все резюме'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        if not os.path.exists(SAVE_PATH_FOLDER):
            os.mkdir(SAVE_PATH_FOLDER)
        if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
            os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)
        if os.listdir(SAVE_PATH_FOLDER) != []:
            logger.info("Resume list is not empty, proceeding with deletion confirmation")
            global check_digits
            check_digits = randint(0,9999)
            logger.debug("Generated confirmation code %d for user %s", check_digits, message.from_user.id)
            await message.answer(f'Вы уверены, что хотите удалить все резюме из базы данных?\nЕсли уверены, напишите число: {check_digits}')
            await state.set_state(cv_removing.confirmation)
        else:
            await message.answer('Нет доступных резюме', reply_markup=kb.additional_tools)
            logger.info("No resumes available for deletion")
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to delete all resumes", message.from_user.id)
    
    

@router.message(cv_removing.confirmation)
async def reg_two(message: Message, state: FSMContext):
    await state.update_data(confirmation = message.text)
    logger.info("Received deletion confirmation input from user %s: %s", message.from_user.id, message.text)
    data = await state.get_data()
    if str(data['confirmation']) == str(check_digits):
        logger.info("User %s provided correct confirmation code, proceeding with resume deletion", message.from_user.id)
        await db.delete_cv()
        shutil.rmtree(SAVE_PATH_FOLDER)
        logger.info("All resumes deleted by user %s", message.from_user.id)
        await message.answer('Все резюме удалены')
        await state.clear()

    else:
        logger.warning("User %s provided incorrect confirmation code, cancelling resume deletion", message.from_user.id)
        await message.answer('Вы ввели число неверно. Отмена операции...',reply_markup=kb.additional_tools )
    await state.clear()
    
# Add template
    
@router.message(F.text == '➕ Добавить Шаблоны 📋')
async def template(message: Message):
    logger.info("User %s requested 'Добавить Шаблоны'", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
            os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)
        listings = await db.listi_adding_template()
        if not listings:
            await message.answer("В данный момент нет доступных вакансий")
        paginated_response = await kb.reports_pagination_add_template(listings)
        await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Добавить Шаблоны'", message.from_user.id)
@router.callback_query(F.data.startswith("add_template_next_"))
async def next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[3])
    listings = await db.listi_adding_template()
    paginated_response = await kb.reports_pagination_add_template(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)
    

@router.callback_query(F.data.startswith("add_template_prev_"))
async def previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[3])
    listings = await db.listi_adding_template()
    paginated_response = await kb.reports_pagination_add_template(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("add_templatem_"))
async def page_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[2])
    listings = await db.listi_adding_template()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard1 = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Загрузите Шаблон', callback_data=f"add_template_conf_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='add_template_back')]
        ])
    await callback.message.edit_text(title, reply_markup = back_keyboard1)


@router.callback_query(F.data == 'add_template_back')
async def go_back(callback: CallbackQuery):
    listings = await db.listi_adding_template()
    paginated_response = await kb.reports_pagination_add_template(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("add_template_conf_"))
async def reg_template(callback: CallbackQuery, state: FSMContext):
    number = int(callback.data.split("_")[3])
    listings = await db.listi_adding_template()
    global title_of_chosen_vacancy
    title_of_chosen_vacancy = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    chosen_title_template = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    await state.update_data(chosen_title_template=chosen_title_template)
    await callback.message.edit_text('Отправьте файл')
    await state.set_state(templateState.template_file)


@router.message(templateState.template_file)
async def reg_template_two(message: Message, state: FSMContext, bot=Bot):
    document = message.document
    file_info = await bot.get_file(document.file_id)
    file_path = file_info.file_path
    save_path = os.path.join(SAVE_PATH_FOLDER_TEMPLATES, document.file_name)
    await bot.download_file(file_path, save_path)
    base, extension = os.path.splitext(save_path)
    datetimetemp = datetime.today()
    dt_string = str(datetimetemp.strftime("%d_%m_%Y__%H_%M_%S"))
    new_name = 'Шаблон на должность {vacancy} {date}'.format(vacancy=title_of_chosen_vacancy,date=dt_string)
    new_path = os.path.join(SAVE_PATH_FOLDER_TEMPLATES, new_name + extension)
    os.rename(save_path, new_path)
    await state.update_data(template_file=new_path)
    data = await state.get_data()
    await db.add_template(data['template_file'], data['chosen_title_template'])  # Retrieve from state context
    await state.clear()
    await message.answer('Шаблон добавлен успешно', reply_markup=kb.admin_panel)
    logger.info("User %s added a file for template '%s'", message.from_user.id, title_of_chosen_vacancy)


# Template edit

@router.message(F.text == '✏️ Изменить Шаблоны 📋')
async def template(message: Message):
    logger.info("User %s requested 'Изменить Шаблоны '", message.from_user.id)
    if not os.path.exists(SAVE_PATH_FOLDER_TEMPLATES):
        os.mkdir(SAVE_PATH_FOLDER_TEMPLATES)
    listings = await db.listi_editing_template()
    if not listings:
        await message.answer("В данный момент нет доступных вакансий")
        return

    paginated_response = await kb.reports_pagination2(listings)
    await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("edit_next_template_"))
async def next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[3])
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination2(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("edit_prev_template_"))
async def previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[3])
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination2(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("edit_template_"))
async def page_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[2])
    listings = await db.listi_editing_template()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard1 = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Загрузите Шаблон', callback_data=f"page_edit_template_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='template_back')]
        ])
    await callback.message.edit_text(title, reply_markup = back_keyboard1)


@router.callback_query(F.data == 'template_back')
async def go_back(callback: CallbackQuery):
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination2(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("page_edit_template_"))
async def reg_template(callback: CallbackQuery, state: FSMContext):
    number = int(callback.data.split("_")[3])
    listings = await db.listi_editing_template()
    global title_of_chosen_vacancy
    title_of_chosen_vacancy = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    chosen_title_template = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    await state.update_data(chosen_title_template=chosen_title_template)
    await callback.message.edit_text('Отправьте файл')
    await state.set_state(templateedition.template_file)


@router.message(templateedition.template_file)
async def reg_template_two(message: Message, state: FSMContext, bot=Bot):
    document = message.document
    file_info = await bot.get_file(document.file_id)
    file_path = file_info.file_path
    save_path = os.path.join(SAVE_PATH_FOLDER_TEMPLATES, document.file_name)
    await bot.download_file(file_path, save_path)
    base, extension = os.path.splitext(save_path)
    datetimetemp = datetime.today()
    dt_string = str(datetimetemp.strftime("%d_%m_%Y__%H_%M_%S"))
    new_name = 'Шаблон на должность {vacancy} {date}'.format(vacancy=title_of_chosen_vacancy,date=dt_string)
    new_path = os.path.join(SAVE_PATH_FOLDER_TEMPLATES, new_name + extension)
    temp_text = await db.del_temp(title_of_chosen_vacancy)
    os.rename(save_path, new_path)
    await db.delete_template(title_of_chosen_vacancy)
    # await state.update_data(template_file=new_path)
    await db.edit_template(new_path,title_of_chosen_vacancy) # Retrieve from state context
    await state.clear()
    await message.answer('Шаблон добавлен успешно', reply_markup=kb.admin_panel)
    logger.info("Template '%s' edited successfully by user %s", title_of_chosen_vacancy, message.from_user.id)
    temp_path = temp_text[0]
    os.remove(temp_path)




# Template Delete

@router.message(F.text == '❌ Удалить Шаблоны 📋')  
async def temp_delete(message: Message):
    logger.info("User %s requested 'Удалить Шаблоны '", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        listings = await db.listi_editing_template()
        if not listings:
            await message.answer("В данный момент нет доступных вакансий")
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Удалить Шаблоны '", message.from_user.id)
    paginated_response = await kb.reports_pagination_delete_template(listings)
    await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)

        
@router.callback_query(F.data.startswith("template_del_next_"))
async def del_temp_next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[-1])
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination_delete_template(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("template_del_prev_"))
async def del_temp_previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[-1])
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination_delete_template(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("del_temp_title_"))
async def del_temp_page_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[-1])
    listings = await db.listi_editing_template()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard1 = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Удалить Шаблон', callback_data=f"del_temp_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='del_template_back')]
        ])
    await callback.message.edit_text(title, reply_markup = back_keyboard1)


@router.callback_query(F.data == 'del_template_back')
async def go_back(callback: CallbackQuery):
    listings = await db.listi_editing_template()
    paginated_response = await kb.reports_pagination_delete_template(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("del_temp_"))
async def temp_delete_conf(callback: CallbackQuery):
    number = int(callback.data.split("_")[-1])
    back_keyboard_delete = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Да, Удалить', callback_data=f"delete_conf_temp_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='back_delete')]
        ])
    await callback.message.edit_text('Вы уверены?', reply_markup=back_keyboard_delete)

@router.callback_query(F.data.startswith("delete_conf_temp_"))
async def temp_delete(callback: CallbackQuery):
    number = int(callback.data.split("_")[-1])
    listings = await db.listi_editing_template()
    chosen_title_delete_conf = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    temp_text = await db.del_temp(chosen_title_delete_conf)
    temp_path = temp_text[0]
    os.remove(temp_path)
    await db.delete_template(chosen_title_delete_conf)
    await callback.message.edit_text('Шаблон удален!✅', reply_markup=None)
    logger.info("Template '%s' deleted successfully by user %s", chosen_title_delete_conf)
    await callback.message.answer('Главное меню 🏠', reply_markup=kb.admin_panel)


# Title edit


@router.message(F.text == '✏️Изменить вакансии 💼')
async def edit_titles(message: Message):
    logger.info("User %s requested 'Изменить вакансии '", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        listings = await db.listi()
        if not listings:
            await message.answer("В данный момент нет доступных вакансий")
        else:
            paginated_response = await kb.reports_pagination1(listings)
            await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges for 'Изменить вакансии'", message.from_user.id)
    

@router.callback_query(F.data.startswith("nextedit_"))
async def next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination1(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("prevedit_"))
async def previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination1(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("titlech_"))
async def page_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[1])
    listings = await db.listi()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard1 = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Изменить название', callback_data=f"edittitlech_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='backedit')]
        ])
    await callback.message.edit_text(title, reply_markup = back_keyboard1)


@router.callback_query(F.data == 'backedit')
async def go_back(callback: CallbackQuery):
    listings = await db.listi()
    paginated_response = await kb.reports_pagination1(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("edittitlech_"))
async def reg_edit_title(callback: CallbackQuery, state: FSMContext):
    number = int(callback.data.split("_")[1])
    listings = await db.listi()
    global chosen_title
    chosen_title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    await callback.message.edit_text('Напишите новое название вакансии')
    await state.set_state(edit_title.n_title)



@router.message(edit_title.n_title)
async def reg_edit_description(message: Message, state: FSMContext):
    await state.update_data(n_title = message.text)
    await state.set_state(edit_title.o_title)
    await state.update_data(o_title = chosen_title)
    data = await state.get_data()
    await db.edit_title(data['n_title'], data['o_title'])
    await state.clear()
    global chosen_title_description
    chosen_title_description = message.text
    await message.answer('Напишите новое описание. Напишите . если не хотите менять описание')
    await state.set_state(edit_description.n_description)


@router.message(edit_description.n_description)
async def reg_edit_describtion_two(message: Message, state: FSMContext):
    await state.update_data(n_description = message.text)
    if message.text != '.':
        await state.set_state(edit_description.o_description)
        await state.update_data(o_description = chosen_title_description)
        data = await state.get_data()
        await db.edit_title_description(data['n_description'], data['o_description'])
        await state.clear()
        await message.answer('Вакансия изменена ', reply_markup=kb.admin_panel)
        logger.info("Vacancy '%s' edited successfully", chosen_title_description)
    else:
        await state.clear()
        await message.answer('Вакансия изменена. Описание не изменено', reply_markup=kb.admin_panel)
        logger.info("Vacancy '%s' edited without changing description", chosen_title_description)







# Title delete


@router.message(F.text == '❌ Удалить вакансии 💼')
async def delete_titles(message: Message):
    logger.info("User %s requested to delete job titles", message.from_user.id)
    if await db.isitadmin(message.from_user.id):
        listings = await db.listi()
        if not listings:
            await message.answer("В данный момент нет доступных вакансий")
            logger.warning("No job titles found to delete")
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to delete job titles", message.from_user.id)
    paginated_response = await kb.reports_pagination_delete_title(listings)
    await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("delete_next_"))
async def next_page_delete_title(callback: CallbackQuery):
    page = int(callback.data.split("_")[-1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_delete_title(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("delete_prev_"))
async def previous_page_delete_title(callback: CallbackQuery):
    page = int(callback.data.split("_")[-1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_delete_title(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("delete_title_"))
async def page_report_delete_title(callback: CallbackQuery):
    number = int(callback.data.split("_")[-1])
    listings = await db.listi()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard1 = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Удалить вакансию', callback_data=f"con_delete_title_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='back_delete')]
        ])
    await callback.message.edit_text(title, reply_markup = back_keyboard1)


@router.callback_query(F.data == 'back_delete')
async def go_back_delete(callback: CallbackQuery):
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_delete_title(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("con_delete_title_"))
async def title_delete_conf(callback: CallbackQuery):
    number = int(callback.data.split("_")[-1])
    listings = await db.listi()
    global chosen_title_delete
    chosen_title_delete = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    back_keyboard_delete = InlineKeyboardMarkup(inline_keyboard = [
        [InlineKeyboardButton(text='Да, Удалить', callback_data=f"delete_conf_title_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='back_delete')]
        ])
    await callback.message.edit_text('Вы уверены?', reply_markup=back_keyboard_delete)

@router.callback_query(F.data.startswith("delete_conf_title_"))
async def title_delete(callback: CallbackQuery, state: FSMContext):
    number = int(callback.data.split("_")[-1])
    listings = await db.listi()
    chosen_title_delete_conf = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    await state.set_state(delete_title.delete_title)
    await state.update_data(delete_title = chosen_title_delete_conf)
    data = await state.get_data()
    await db.delete_title(data['delete_title'])
    await state.clear()
    await callback.message.answer('Вакансия удалена!', reply_markup=kb.admin_panel)
    logger.info("Job title '%s' successfully deleted", chosen_title_delete_conf)

#downloading cv by vacancy

@router.message(F.text == '📥 Скачать резюме 📝')
async def send_titles(message: Message):
    if await db.name_check(message.from_user.id):
        if not os.path.exists(SAVE_PATH_FOLDER):
            os.mkdir(SAVE_PATH_FOLDER)
        listings = await db.listi()
        if not listings:
            if await db.isitadmin(message.from_user.id):
                await message.answer("В данный момент нет доступных вакансий", reply_markup=kb.admin_panel_addition)
            else:
                await message.answer("В данный момент нет доступных вакансий", reply_markup=kb.main)
        paginated_response = await kb.reports_pagination_download_cv(listings)
        await message.answer(paginated_response.text, reply_markup=paginated_response.keyboard)
    elif await db.name_check(message.from_user.id) == False:
        await message.answer("Вы не зарегистрированы. Введите /start для регистрации.")  

@router.callback_query(F.data.startswith("cv_downloading_list_next_"))
async def next_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_download_cv(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("cv_downloading_list_prev_"))
async def previous_page(callback: CallbackQuery):
    page = int(callback.data.split("_")[1])
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_download_cv(listings, page)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)


@router.callback_query(F.data.startswith("choosen_title_to_download_title_"))
async def show_report(callback: CallbackQuery):
    number = int(callback.data.split("_")[5])
    listings = await db.listi()
    title = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    description = await db.vacancy_list_description(title)
    back_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Скачать резюме', callback_data=f"cv_to_download_title_{number}")],
        [InlineKeyboardButton(text='Назад', callback_data='back_from_downloading_cv')]
    ])
    description_text = description[0] if description else "Описание отсутствует"
    message_text = f"*{title}*\n\n{description_text}"
    

    await callback.message.edit_text(message_text, parse_mode='HTML', reply_markup=back_keyboard)


@router.callback_query(F.data == 'back_from_downloading_cv')
async def go_back(callback: CallbackQuery):
    listings = await db.listi()
    paginated_response = await kb.reports_pagination_download_cv(listings)
    await callback.message.edit_text(paginated_response.text, reply_markup=paginated_response.keyboard)

@router.callback_query(F.data.startswith("cv_to_download_title_"))
async def req_cv_title(callback: CallbackQuery, bot: Bot):
    number = int(callback.data.split("_")[4])
    listings = await db.listi()
    title_of_chosen_vacancy = listings[number - 1].split(" ", 1)[1]  # Get the title based on the number
    cv_path = await db.get_cv_by_vacancy_name(title_of_chosen_vacancy)
    if cv_path:
        await callback.message.edit_text(f"Скачивание всех резюме отправленных на вакансию {title_of_chosen_vacancy}")
        for cv in cv_path:
            document = FSInputFile(cv)  # Преобразуем путь к файлу в объект InputFile
            await bot.send_document(callback.message.chat.id, document)
    else:
        await callback.message.edit_text(f"Резюме на вакансию {title_of_chosen_vacancy} отсутствуют")




# Show Admins

@router.message(Command('showadmins'))
async def reg_edit_two(message: Message):
    logger.info("User %s requested to view administrators", message.from_user.id)
    if message.from_user.id in admin_id:
        admins = await db.get_admins()
        if admins:
            formatted_admins = "\n".join([f"ID: {admin[0]}, Name: {admin[1]}" for admin in admins])
            await message.answer(f"Список Администраторов:\n{formatted_admins}", reply_markup=kb.admin_panel)
        else:
            await message.answer("Администраторы не найдены.", reply_markup=kb.main)
    else:
        await message.answer('У вас недостаточно привилегий для выполнения этой команды')
        logger.warning("User %s does not have admin privileges to view administrators", message.from_user.id)

@router.message(Command('addadmin'))
async def add_admin_handler(message: Message):
    if await db.isitadmin(message.from_user.id):
        try:
            match = re.match(r'/addadmin (\d+)', message.text)
            if match:
                tgUserId = int(match.group(1))
                await db.add_admin(tgUserId)
                logger.info("User %s added user %s as an admin.", message.from_user.id, tgUserId)
                await message.answer(f"Пользователь с ID {tgUserId} теперь администратор.", reply_markup=kb.main)
            else:
                await message.answer("Неверный формат команды. Используйте: /addadmin {tguserid}", reply_markup=kb.main)
        except Exception as e:
                   await message.answer(f"Произошла ошибка: {e}", reply_markup=kb.main)
    else:
        await message.answer('У вас недостаточно привилегий для выполнения этой команды', reply_markup=kb.main)
        logger.warning("Попытка выполнить команду /addadmin без достаточных привилегий: %s", message.from_user.id)

@router.message(Command('showusers'))
async def view_users_handler(message: Message):
    if message.from_user.id in admin_id:
        all_users = await db.get_all_users()
        if all_users:
            formatted_users = "\n".join([f"ID: {user[0]}, Name: {user[1]}, Admin: {'Yes' if user[2] else 'No'}" for user in all_users])
            logger.info("User %s viewed the list of registered users.", message.from_user.id)
            await message.answer(f"Список зарегистрированных пользователей:\n{formatted_users}", reply_markup=kb.main)
        else:
            await message.answer("Пользователи не найдены.", reply_markup=kb.main)
    else:
        await message.answer('У вас недостаточно привилегий для выполнения этой команды', reply_markup=kb.main)
        logger.warning("Попытка выполнить команду /showusers без достаточных привилегий: %s", message.from_user.id)

@router.message(Command('removeadmin'))
async def remove_admin_handler(message: Message):
    if message.from_user.id in admin_id:
        try:
            match = re.match(r'/removeadmin (\d+)', message.text)
            if match:
                tgUserId = int(match.group(1))
                if tgUserId != message.from_user.id:
                    await db.remove_admin(tgUserId)
                    await message.answer(f"Пользователь с ID {tgUserId} больше не администратор.")
                    logger.info("User %s removed user %s from admins.", message.from_user.id, tgUserId)
                else:
                    await message.answer("Вы не можете удалить себя сами из списка администраторов!.")
                    logger.warning("User %s attempted to remove themselves from admins.", message.from_user.id)
            else:
                await message.answer("Неверный формат команды. Используйте: /removeadmin {tguserid}")
        except Exception as e:
            await message.answer(f"Произошла ошибка: {e}")
    else:
        await message.answer('У вас недостаточно привилегий для выполнения этой команды')
        logger.warning("Попытка выполнить команду /removeadmin без достаточных привилегий: %s", message.from_user.id)


