from aiogram.types import ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import NamedTuple



main = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='Показать вакансии 📄'
        )

    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )

admin_panel_addition = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='Показать вакансии 📄'
        ),
        KeyboardButton(
            text='Панель Администратора 🛠️'
        )
    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )

admin_panel = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='Вакансии 💼'
        ),
        KeyboardButton(
            text='Шаблоны 📋'
        )
    ],
    [
        KeyboardButton(
            text='Дополнительные действия ⚙️' # удалить все вакансии или удалить все шаблоны, нужно проверку добавить с паролем или повтором ввода числа
        )
    ],
    [
        KeyboardButton(
            text='Главное меню 🏠'
        )
    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )
admin_panel_template = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='➕ Добавить Шаблоны 📋'
        ),
        KeyboardButton(
            text='❌ Удалить Шаблоны 📋'
        )
    ],
    [
        KeyboardButton(
            text='✏️ Изменить Шаблоны 📋'
        )
    ],
    [
        KeyboardButton(
            text='Главное меню 🏠'
        )
    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )
                           
admin_panel_vacancy = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='Показать вакансии 📄'
        ),
        KeyboardButton(
            text='➕ Добавить вакансии 💼'
        )
    ],
    [
        KeyboardButton(
            text='❌ Удалить вакансии 💼'
        ),
        KeyboardButton(
            text='✏️Изменить вакансии 💼'
        )
    ],
    [
        KeyboardButton(
            text='Главное меню 🏠'
        )
    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )

client_panel = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text=''
        )
    ]
])




additional_tools = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(
            text='🗑️ Удалить все вакансии 💼'
        ),
        KeyboardButton(
            text='🗑️ Удалить все шаблоны 📋'
        )
    ],
    [
        KeyboardButton(
            text='📥 Скачать все резюме 📝'
        ),    
        KeyboardButton(
            text='📥 Скачать резюме 📝'
        )
    ],
    [
        KeyboardButton(
            text='🗑️Удалить все резюме 📝'
        )
    ],
    [
        KeyboardButton(
            text='Главное меню 🏠'
        )
    ]
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Choose from menu'
                           )





ITEMS_PER_PAGE = 10  # Per item number
class PaginatedResponse(NamedTuple):
    text: str
    keyboard: InlineKeyboardMarkup


class PaginatedResponse1(NamedTuple): #editing
    text: str
    keyboard: InlineKeyboardMarkup

class pagination_for_admins(NamedTuple): #editing
    text: str
    keyboard: InlineKeyboardMarkup

async def reports_pagination(reports, page: int = 1) -> PaginatedResponse:
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"title_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"prev_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"next_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse(text=report_text, keyboard=keyboard.adjust(4).as_markup())



async def reports_pagination1(reports, page: int = 1) -> PaginatedResponse1: # for editing vacancy
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"titlech_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"prevedit_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"nextedit_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse1(text=report_text, keyboard=keyboard.adjust(4).as_markup())


async def reports_pagination2(reports, page: int = 1) -> PaginatedResponse1: # for editing vacancy
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"edit_template_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"edit_prev_template_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"edit_next_template_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse1(text=report_text, keyboard=keyboard.adjust(4).as_markup())


# Title delete

async def reports_pagination_delete_title(reports, page: int = 1) -> PaginatedResponse:
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"delete_title_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"delete_prev_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"delete_next_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse(text=report_text, keyboard=keyboard.adjust(4).as_markup())


# Template Delete

async def reports_pagination_delete_template(reports, page: int = 1) -> PaginatedResponse:
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"del_temp_title_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"template_del_prev_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"template_del_next_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse(text=report_text, keyboard=keyboard.adjust(4).as_markup())


async def reports_pagination_add_template(reports, page: int = 1) -> PaginatedResponse1: # for editing vacancy
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"add_templatem_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"add_template_prev_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"add_template_next_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse1(text=report_text, keyboard=keyboard.adjust(4).as_markup())

#download cv

async def reports_pagination_download_cv(reports, page: int = 1) -> PaginatedResponse:
    keyboard = InlineKeyboardBuilder()
    start_index = (page - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paginated_reports = reports[start_index:end_index]

    for report in paginated_reports:
        number = report.split()[0]  # Extract the number from the report
        keyboard.add(InlineKeyboardButton(text=number, callback_data=f"choosen_title_to_download_title_{number}"))

    # Add navigation buttons
    if page > 1:
        keyboard.add(InlineKeyboardButton(text="Предыдушая", callback_data=f"cv_downloading_list_prev_{page-1}"))
    if end_index < len(reports):
        keyboard.add(InlineKeyboardButton(text="Следующая", callback_data=f"cv_downloading_list_next_{page+1}"))

    report_text = '\n'.join(paginated_reports)
    return PaginatedResponse(text=report_text, keyboard=keyboard.adjust(4).as_markup())