from main5 import admin_id
import os
import sqlite3 as sq

database_path = os.path.join('tg.db')
db = sq.connect(database_path)


cur = db.cursor()


async def db_start():
    cur.execute("CREATE TABLE IF NOT EXISTS vacancy("
                "v_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                "title VARCHAR(200), "
                "uploadDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, "
                "templatePath VARCHAR,"
                "description VARCHAR"
                "tgUserId INTEGER)")

    cur.execute("CREATE TABLE IF NOT EXISTS users("
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                "tgUserId INTEGER, "
                "fullName VARCHAR(100), "
                "isAdmin INTEGER NOT NULL)")
    
    cur.execute("CREATE TABLE IF NOT EXISTS cv("
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                "tgUserId INTEGER, "
                "cvPath VARCHAR, "
                "title VARCHAR(200))")
    db.commit()

    for admin in admin_id:
        # Проверяем, существует ли пользователь с указанным tgUserId
        cur.execute("SELECT isAdmin FROM users WHERE tgUserId = ?", (admin,))
        result = cur.fetchone()

        if result is None:
            # Пользователь не существует, вставляем новую запись
            cur.execute("INSERT INTO users (tgUserId, isAdmin) VALUES (?, 1)", (admin,))
        else:
            isAdmin = result[0]
            if isAdmin == 0:
                # Пользователь существует, но не является админом, обновляем запись
                cur.execute("UPDATE users SET isAdmin = 1 WHERE tgUserId = ?", (admin,))
        db.commit()

async def add_vacancy(vacancy_title, vacancy_description):
    cur.execute("INSERT INTO vacancy (title, description) VALUES ('{key}', '{key2}')".format(key=vacancy_title, key2=vacancy_description))
    db.commit()

async def name_check(tguserid):
    cur.execute("SELECT fullName FROM users WHERE tgUserId =({key})".format(key=tguserid)) # удалены кавычки ибо int
    fetching_name = cur.fetchall()
    db.commit()
    if fetching_name == [(None,)] or fetching_name == []:
        return False
    else:
        return True
    
async def edit_title_description(n_description, o_description):
    cur.execute("UPDATE vacancy SET description = ('{key}') WHERE title = ('{key2}');".format(key=n_description, key2=o_description))
    db.commit()

async def insert_name(tguserid, name):
    # Проверяем, существует ли пользователь с данным tgUserId
    cur.execute("SELECT * FROM users WHERE tgUserId = ?", (tguserid,))
    user = cur.fetchone()
    
    if user:
        # Если пользователь существует, обновляем его fullName
        cur.execute("UPDATE users SET fullName = ? WHERE tgUserId = ?", (name, tguserid))
    else:
        # Если пользователь не существует, создаем новую запись
        cur.execute("INSERT INTO users (tgUserId, fullName, isAdmin) VALUES (?, ?, 0)", (tguserid, name))
    
    db.commit()

async def file_renaming_name_getting(tguserid):
    cur.execute("SELECT fullName FROM users WHERE tgUserId =({key})".format(key=tguserid)) # удалены кавычки ибо int
    fetching_name = cur.fetchall()
    db.commit()
    if fetching_name == []:
        return None
    else:
        result = fetching_name[0][0]
        return result


async def edit_title(n_title, o_title):
    cur.execute("UPDATE vacancy SET title = ('{key}') WHERE title = ('{key2}');".format(key=n_title, key2=o_title))
    db.commit()
     
async def isitadmin(tguserid):
    cur.execute("SELECT isAdmin FROM users WHERE tgUserId = ?", (tguserid,))
    result = cur.fetchall()
    db.commit()
    if result is None or result[0] == (0,):
        return False
    else:
        return True
    
async def delete_cv(): #удаление всех cv
    cur.execute("DELETE from cv")
    db.commit()

async def delete_vacancy():
    cur.execute("DELETE FROM vacancy")
    db.commit()

async def add_template(template_file, title):
    cur.execute("UPDATE vacancy SET templatePath = ('{key}') WHERE title = ('{key1}') ".format(key=template_file, key1=title))
    db.commit()


async def edit_template(template_file, title):
    cur.execute('UPDATE vacancy SET templatePath = "?" WHERE title = "?" ', (template_file, title))
    db.commit()


async def delete_title(delete_title):
    cur.execute("DELETE FROM vacancy WHERE title = ('{key}');".format(key=delete_title))
    db.commit()


async def del_temp(del_temp_select):
    cur.execute('SELECT templatePath FROM vacancy WHERE title = ?', (del_temp_select,))
    result = cur.fetchone()
    db.commit()
    return result


async def delete_all_templates():
    cur.execute("UPDATE vacancy SET templatePath = (NULL)")
    db.commit()

async def delete_template(title):
    cur.execute("UPDATE vacancy SET templatePath = (NULL) WHERE title = ('{key}')".format(key=title))
    db.commit()

async def add_cv(tguserid,cvPath, title):
    cur.execute("INSERT INTO cv (cvPath, title, tgUserId) VALUES ('{key}', '{key2}', {key3});".format(key=cvPath, key2=title, key3=tguserid))
    db.commit()
    db.commit()


async def edit_template(new_path, chosen_title_template):
    cur.execute('UPDATE vacancy SET templatePath = ("{key}") WHERE title = ("{key2}")'.format(key=new_path, key2=chosen_title_template))
    db.commit()
    
async def get_admins():
    cur.execute("SELECT tgUserId, fullName FROM users WHERE isAdmin = 1")
    fetching_name = cur.fetchall()
    db.commit()
    if fetching_name == []:
        return None
    else:
        result = fetching_name
        return result

async def add_admin(tgUserId):
    cur.execute("SELECT isAdmin FROM users WHERE tgUserId = ?", (tgUserId,))
    result = cur.fetchone()
    if result is None:
        cur.execute("INSERT INTO users (tgUserId, isAdmin) VALUES (?, 1)", (tgUserId,))
    else:
        if result[0] == 0:
            cur.execute("UPDATE users SET isAdmin = 1 WHERE tgUserId = ?", (tgUserId,))
    db.commit()

async def get_all_users():
    cur.execute("SELECT tgUserId, fullName, isAdmin FROM users")
    all_users = cur.fetchall()
    return all_users

async def remove_admin(tgUserId):
    cur.execute("UPDATE users SET isAdmin = 0 WHERE tgUserId = ?", (tgUserId,))
    db.commit()

async def listi_adding_template():
    listing = []
    cur.execute('SELECT title FROM vacancy WHERE templatePath IS NULL')
    db.commit()
    allVacancy = cur.fetchall()
    for index, title in enumerate(allVacancy, start=1):
        listing.append(f"{index} {title[0]}")
    return listing

async def listi_editing_template():
    listing = []
    cur.execute('SELECT title FROM vacancy WHERE templatePath IS NOT NULL')
    allVacancy = cur.fetchall()
    for index, title in enumerate(allVacancy, start=1):
        listing.append(f"{index} {title[0]}")
    return listing
#Downloading cv by vacancy name

async def get_cv_by_vacancy_name(vacancy_name):
    cur.execute("SELECT cvPath FROM cv WHERE title = ?", (vacancy_name,))
    result = cur.fetchall()
    flat_list = [item[0] for item in result]
    db.commit()
    return flat_list

#проверка существует ли шаблон на вакансию
async def check_template_existence(title):
    cur.execute("SELECT templatePath FROM vacancy WHERE title = ?", (title,))
    result = cur.fetchone()
    result = str(result).strip("'(),")
    if result == 'None':
        return False
    else:
        return result
# Client Call database ----------------------------
async def listi():
    listing = []
    cur.execute('SELECT title FROM vacancy')
    allVacancy = cur.fetchall()
    for index, title in enumerate(allVacancy, start=1):
        listing.append(f"{index} {title[0]}")
    return listing  

async def listi_vacancy_unqueity():
    listings = []
    cur.execute('SELECT title FROM vacancy')
    allVacancy = cur.fetchall()
    for vacancy in allVacancy:
        listing = str(vacancy).strip("'(),")
        listings.append(listing)
    return listings

async def vacancy_list_description(vacancy_list_description):
    cur.execute('SELECT description FROM vacancy WHERE title = ?', (vacancy_list_description,))
    result = cur.fetchone()
    db.commit()
    return result

