from aiogram import Bot, Dispatcher, types
from aiogram.dispatcher.middlewares.base import BaseMiddleware
from aiogram.exceptions import TelegramForbiddenError
from aiogram.filters import Command
from aiogram.types import Message
from collections import defaultdict
from dotenv import load_dotenv
import asyncio
import logging
import os
import sys
import time




load_dotenv()
admin_id2 = os.getenv('GENERAL_ADMIN')
admin_id1 = admin_id2.split(",")
admin_id = list(map(int, admin_id1))

import core.database.db as db
from core.handlers.basic import router
from core.handlers.client_handler import client_router

bot = Bot(os.getenv('TOKEN'))
dp = Dispatcher(bot=bot)

class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, rate_limit=0.5):
        self.rate_limit = rate_limit
        self.user_timestamps = defaultdict(lambda: 0)
        super().__init__()

    async def __call__(self, handler, event, data):
        current_time = time.time()
        user_id = event.from_user.id
        if current_time - self.user_timestamps[user_id] < self.rate_limit:
            try:
                await event.answer("Вы отправляете сообщения слишком быстро!")
            except TelegramForbiddenError:
                logging.warning(f"Failed to send message to user {user_id} - bot was blocked.")
            return
        self.user_timestamps[user_id] = current_time
        return await handler(event, data)

class CustomLoggingMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        logging.info(f"Handling event from user {event.from_user.id}")
        return await handler(event, data)

async def main():
    dp.include_router(client_router)
    dp.include_router(router)
    dp.message.middleware(ThrottlingMiddleware(rate_limit=1.0))  # Throttle to 1 message per second per user
    dp.message.middleware(CustomLoggingMiddleware())  # Custom logging middleware
    await db.db_start()
    await dp.start_polling(bot)

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Exit')

@router.message(Command('restart'))
async def remove_admin_handler(message: Message):
    if message.from_user.id in admin_id:
        await message.reply("Бот перезагружается. Нажмите /start через 10 секунд")
        os.execv(sys.executable, ['python'] + sys.argv)
    else:
        await message.answer('У вас недостаточно привелегий для выполнения этой команды')