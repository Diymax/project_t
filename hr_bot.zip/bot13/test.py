import sqlite3 as sq
import os
db = sq.connect(r"tg.db")
cur = db.cursor()
SAVE_PATH_FOLDER_TEMPLATES = 'templates'
SAVE_PATH_FOLDER = 'cv'

def get_cv_by_vacancy_name(vacancy_name):
    cur.execute("SELECT cvPath FROM cv WHERE title = ?", (vacancy_name,))
    result = cur.fetchall()
    flat_list = [item[0] for item in result]
    db.commit()
    return flat_list
print(get_cv_by_vacancy_name("Вакансия1"))